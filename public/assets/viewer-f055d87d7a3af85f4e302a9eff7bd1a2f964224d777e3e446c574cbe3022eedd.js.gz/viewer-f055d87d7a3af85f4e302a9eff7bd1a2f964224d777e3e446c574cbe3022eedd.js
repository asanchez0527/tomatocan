$(document).ready(() => {
  alert("this file has loaded")
});
